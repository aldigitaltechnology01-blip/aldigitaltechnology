AL DIGITAL TECHNOLOGY — WEBSITE PROJECT

Included pages
- index.html      Home page
- services.html   Services page
- about.html      About page
- contact.html    Contact page
- assets/style.css   Responsive design, glow effects, animation and layout
- assets/main.js     Animated digital network background, mobile menu, reveal effects and WhatsApp form handler
- assets/al-logo.jpg Exact original full logo supplied in chat
- assets/al-logo-original.jpg Copy of the original logo asset
- assets/al-mark.png Cropped AL symbol from the supplied logo for the compact navigation mark

HOW TO PREVIEW
1. Extract the ZIP to a folder.
2. Open index.html in Chrome, Edge, Firefox, or a mobile browser.
3. Use the top navigation to move between Home, Services, About, and Contact.

CONTACT FORM
This is a front-end static website and has no server-side backend. Submitting the contact form opens WhatsApp with the visitor's filled-in message addressed to +92 331 3452741. The visitor still needs to press Send in WhatsApp.

SOCIAL LINKS
Facebook, Instagram, LinkedIn, and WhatsApp buttons use the links and phone number supplied in chat. The email shown on the Contact page was taken from the supplied reference screenshot: aldigitaltechnology01@gmail.com.

NOT INCLUDED YET
No Google Business/Profile link was present in the message, so a Google link has not been added. It can be inserted when the correct link is supplied.

CUSTOMIZATION
Edit page text in the HTML files, colors/layout in assets/style.css, and interactions in assets/main.js. No external JavaScript libraries or paid fonts are required.
