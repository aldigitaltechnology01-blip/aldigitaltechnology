(() => {
  const body = document.body;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  // Responsive mobile navigation
  const menuButton = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav-links');
  if (menuButton && nav) {
    menuButton.addEventListener('click', () => {
      const isOpen = nav.classList.toggle('open');
      menuButton.setAttribute('aria-expanded', String(isOpen));
      menuButton.setAttribute('aria-label', isOpen ? 'Close navigation menu' : 'Open navigation menu');
      menuButton.textContent = isOpen ? '×' : '☰';
    });
    nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
      nav.classList.remove('open');
      menuButton.setAttribute('aria-expanded', 'false');
      menuButton.setAttribute('aria-label', 'Open navigation menu');
      menuButton.textContent = '☰';
    }));
    document.addEventListener('click', event => {
      if (!nav.contains(event.target) && !menuButton.contains(event.target)) {
        nav.classList.remove('open');
        menuButton.setAttribute('aria-expanded', 'false');
        menuButton.textContent = '☰';
      }
    });
  }

  // Reveal page sections when they enter the viewport
  const reveals = document.querySelectorAll('.reveal:not(.visible)');
  if ('IntersectionObserver' in window && !reduceMotion) {
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('visible');
          obs.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12, rootMargin: '0px 0px -35px 0px' });
    reveals.forEach(el => observer.observe(el));
  } else {
    reveals.forEach(el => el.classList.add('visible'));
  }

  // Animated network canvas used as a subtle, animated digital-world background
  const canvas = document.getElementById('network-canvas');
  if (canvas && !reduceMotion) {
    const ctx = canvas.getContext('2d');
    let w = 0, h = 0, dpr = 1, points = [], raf = 0;
    const pointer = { x: -1000, y: -1000 };
    const resize = () => {
      dpr = Math.min(window.devicePixelRatio || 1, 1.6);
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = Math.round(w * dpr);
      canvas.height = Math.round(h * dpr);
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const amount = Math.min(100, Math.max(32, Math.round(w * h / 14500)));
      points = Array.from({ length: amount }, () => ({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - .5) * .22,
        vy: (Math.random() - .5) * .22,
        r: Math.random() * 1.5 + .55,
        phase: Math.random() * Math.PI * 2
      }));
    };
    const draw = t => {
      ctx.clearRect(0, 0, w, h);
      for (let i = 0; i < points.length; i++) {
        const p = points[i];
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < -8) p.x = w + 8;
        if (p.x > w + 8) p.x = -8;
        if (p.y < -8) p.y = h + 8;
        if (p.y > h + 8) p.y = -8;
        const dxp = p.x - pointer.x, dyp = p.y - pointer.y;
        const nearPointer = dxp * dxp + dyp * dyp < 140 * 140;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r + (Math.sin(t * .001 + p.phase) + 1) * .25, 0, Math.PI * 2);
        ctx.fillStyle = nearPointer ? 'rgba(54,235,255,.95)' : 'rgba(40,164,255,.65)';
        ctx.fill();
        for (let j = i + 1; j < points.length; j++) {
          const q = points[j], dx = p.x - q.x, dy = p.y - q.y;
          const distance = Math.sqrt(dx * dx + dy * dy);
          if (distance < 128) {
            const alpha = (1 - distance / 128) * .19;
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(q.x, q.y);
            ctx.strokeStyle = `rgba(14,145,255,${alpha})`;
            ctx.lineWidth = .7;
            ctx.stroke();
          }
        }
      }
      raf = window.requestAnimationFrame(draw);
    };
    canvas.addEventListener('pointermove', e => { pointer.x = e.clientX; pointer.y = e.clientY; }, { passive: true });
    canvas.addEventListener('pointerleave', () => { pointer.x = -1000; pointer.y = -1000; }, { passive: true });
    window.addEventListener('resize', resize, { passive: true });
    resize();
    raf = window.requestAnimationFrame(draw);
    document.addEventListener('visibilitychange', () => {
      if (document.hidden && raf) window.cancelAnimationFrame(raf);
      else if (!document.hidden && !reduceMotion) raf = window.requestAnimationFrame(draw);
    });
  }

  // The contact form opens WhatsApp with the visitor's filled-in message.
  const contactForm = document.getElementById('contact-form');
  if (contactForm) {
    contactForm.addEventListener('submit', event => {
      event.preventDefault();
      if (!contactForm.reportValidity()) return;
      const data = new FormData(contactForm);
      const name = String(data.get('name') || '').trim();
      const email = String(data.get('email') || '').trim();
      const service = String(data.get('service') || '').trim();
      const message = String(data.get('message') || '').trim();
      const lines = [
        'Hello AL Digital Technology,',
        '',
        `My name is: ${name}`,
        email ? `Email: ${email}` : '',
        `Service needed: ${service}`,
        '',
        `Project details: ${message}`
      ].filter(line => line !== '');
      const whatsappUrl = `https://wa.me/923313452741?text=${encodeURIComponent(lines.join('\n'))}`;
      const opened = window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
      if (!opened) window.location.href = whatsappUrl;
    });
  }

  // Footer year and scroll-to-top button
  const year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();
  const scrollTop = document.querySelector('.scroll-top');
  if (scrollTop) {
    window.addEventListener('scroll', () => scrollTop.classList.toggle('show', window.scrollY > 500), { passive: true });
    scrollTop.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }));
  }
})();
